<template>
  <div class="LoginHospitalAdmin">
   
   
    <LoginnHospitalAdmin />
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'
import LoginnHospitalAdmin from '../components/LoginnHospitalAdmin.vue'
export default {
  name: 'LoginHospitalAdmin',
  components: {
     LoginnHospitalAdmin
   }
}
</script>
