<template>
  <div class="LoginPatient">
   
   
    <LoginnPatient />
  </div>
</template>

<script>
// @ is an alias to /src
// import LoginPatient from '../components/LoginPatient.vue'
import LoginnPatient from '../components/LoginnPatient.vue'
export default {
  name: 'LoginPatient',
  components: {
    LoginnPatient
   }
}
</script>
