<template>
  <div class="LoginDoctor">
   
    <LoginnDoctor />
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'
import LoginnDoctor from '../components/LoginnDoctor.vue'
export default {
  name: 'LoginDoctor',
   components: {
   LoginnDoctor
  }
}
</script>
