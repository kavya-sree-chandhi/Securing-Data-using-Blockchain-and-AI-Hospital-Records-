<template>
  <div class="home">
    <homec />
    
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'
import homec from '../components/homec.vue'
export default {
  name: 'Home',
  components: {
    homec
  }
}
</script>
