<template>
    <div>
        <!-- <h1>this is hospital admin dashboard</h1> -->
        <hospitaladmind/>
    </div>
</template>

<script>
// // @ is an alias to /src
// // import LoginPatient from '../components/LoginPatient.vue'
 import hospitaladmind from '../components/hospitaladmind.vue'
export default {
  name: 'HospitalAdminDashboard',
   components: {
    hospitaladmind
  }
}
</script>
