<template>
    <div>
        <!-- <h1>this is doctor dashboard</h1> -->
        <doctord/>
    </div>
</template>

<script>
// // @ is an alias to /src
// // import LoginPatient from '../components/LoginPatient.vue'
 import doctord from '../components/doctord.vue'
export default {
  name: 'DoctorDashboard',
   components: {
    doctord
   }
}
</script>
