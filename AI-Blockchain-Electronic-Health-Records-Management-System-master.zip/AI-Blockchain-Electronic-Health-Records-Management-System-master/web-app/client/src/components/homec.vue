<template>
    <div>
       <!-- <h1>this is  home</h1> -->


    <div class="tagline">

        <p id="tag">MyEHR: The most secure, efficient and highly insightful decentralized Electronic Healthcare System!</p> 

    </div>
    <div class="tagline">

        <p id="tag">Where Care Comes first</p> 

    </div>

    <div>
        <p style="width: 1000px; margin: 2em auto; text-align: center;">EMR is a boon to the healthcare system and its patients. It comes with support to many useful functions, making the lives of doctors and patients easy and hence achieving better care. 
            </p>

            
    </div>

    <p style="text-align: left; margin-left: 30em;">
        - Patient data stored on very secure blockchain
        
       </p>
       <p style="text-align: left;  margin-left: 30em;">
        - Access permission rights for patients
        
       </p>
       <p style="text-align: left;  margin-left: 30em;">
        - Insightful summary of patient data for better understanding
        
       </p>
       <p style="text-align: left; margin-left: 30em;">
        - Medical history timeline for patients
        
       </p>
       <p style="text-align: left; margin-left: 30em;">
        - Reliable admin dashboard for handling doctors and patients
        
       </p>
       <p style="text-align: left; margin-left: 30em;">
        - Details of doctors nearby for the ease of patient
        
       </p>
    
    </div>
</template>

<script>
// import uuid from 'uuid';

export default {
    name: "homec"
   
}
</script>

<style  scoped>

.tagline p {
    text-align: center;
    margin-top: 2.5em;
    font-size: 1.2rem;
    word-spacing: 0em;
}
</style>