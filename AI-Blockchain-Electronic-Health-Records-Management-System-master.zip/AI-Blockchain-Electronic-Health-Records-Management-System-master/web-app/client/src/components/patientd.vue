<template>
    <div>
        <h1>inside pd</h1>
    </div>
</template>

<script>
export default {
    name : "patientd"
}
</script>